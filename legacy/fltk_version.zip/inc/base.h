#ifndef H_BASE
#define H_BASE

// Includes
#include <filesystem>
#include <iostream>
#include <fstream>
#include <vector>

#include "tools/json.hpp"

// Namespaces
using namespace nlohmann;

#endif